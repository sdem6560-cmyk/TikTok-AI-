import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import IdeasPage from './components/IdeasPage.jsx';
import ScenariosPage from './components/ScenariosPage.jsx';
import MediaLibraryPage from './components/MediaLibraryPage.jsx';
import AnalyticsPage from './components/AnalyticsPage.jsx';
import { Lightbulb, FileText, FolderOpen, BarChart3, Sparkles } from 'lucide-react';
import './App.css';

function App() {
  const [currentPage, setCurrentPage] = useState('ideas');

  const navigation = [
    { id: 'ideas', label: 'الأفكار', icon: Lightbulb },
    { id: 'scenarios', label: 'السيناريوهات', icon: FileText },
    { id: 'media', label: 'مكتبة الوسائط', icon: FolderOpen },
    { id: 'analytics', label: 'التحليلات', icon: BarChart3 }
  ];

  const renderPage = () => {
    switch (currentPage) {
      case 'ideas':
        return <IdeasPage />;
      case 'scenarios':
        return <ScenariosPage />;
      case 'media':
        return <MediaLibraryPage />;
      case 'analytics':
        return <AnalyticsPage />;
      default:
        return <IdeasPage />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="h-8 w-8 text-primary" />
              <div>
                <h1 className="text-2xl font-bold">TikTok Content Creator</h1>
                <p className="text-sm text-muted-foreground">مولد أفكار وسيناريوهات الفيديو بالذكاء الاصطناعي</p>
              </div>
            </div>
            <Button variant="outline">تسجيل الدخول</Button>
          </div>
        </div>
      </header>

      {/* Navigation */}
      <nav className="border-b bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="flex gap-2 overflow-x-auto">
            {navigation.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  onClick={() => setCurrentPage(item.id)}
                  className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors whitespace-nowrap ${
                    currentPage === item.id
                      ? 'text-primary border-b-2 border-primary'
                      : 'text-muted-foreground hover:text-foreground'
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </button>
              );
            })}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {renderPage()}
      </main>

      {/* Footer */}
      <footer className="border-t mt-12">
        <div className="container mx-auto px-4 py-6">
          <p className="text-center text-sm text-muted-foreground">
            © 2025 TikTok Content Creator. جميع الحقوق محفوظة.
          </p>
        </div>
      </footer>
    </div>
  );
}

export default App;

