import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { Eye, Heart, Share2, TrendingUp } from 'lucide-react';

export default function AnalyticsPage() {
  const viewsData = [
    { day: 'السبت', views: 1200 },
    { day: 'الأحد', views: 1900 },
    { day: 'الاثنين', views: 1500 },
    { day: 'الثلاثاء', views: 2200 },
    { day: 'الأربعاء', views: 2800 },
    { day: 'الخميس', views: 3100 },
    { day: 'الجمعة', views: 2600 }
  ];

  const engagementData = [
    { day: 'السبت', engagement: 85 },
    { day: 'الأحد', engagement: 92 },
    { day: 'الاثنين', engagement: 78 },
    { day: 'الثلاثاء', engagement: 95 },
    { day: 'الأربعاء', engagement: 88 },
    { day: 'الخميس', engagement: 98 },
    { day: 'الجمعة', engagement: 91 }
  ];

  const stats = [
    {
      title: 'إجمالي المشاهدات',
      value: '15.4K',
      change: '+12.5%',
      icon: Eye,
      color: 'text-blue-500'
    },
    {
      title: 'الإعجابات',
      value: '2.8K',
      change: '+8.2%',
      icon: Heart,
      color: 'text-red-500'
    },
    {
      title: 'المشاركات',
      value: '456',
      change: '+15.3%',
      icon: Share2,
      color: 'text-green-500'
    },
    {
      title: 'معدل التفاعل',
      value: '18.2%',
      change: '+3.1%',
      icon: TrendingUp,
      color: 'text-orange-500'
    }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">التحليلات</h2>
        <p className="text-muted-foreground">
          تتبع أداء فيديوهاتك واحصل على رؤى قيمة
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">
                  {stat.title}
                </CardTitle>
                <Icon className={`h-4 w-4 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{stat.value}</div>
                <p className="text-xs text-muted-foreground">
                  <span className="text-green-500">{stat.change}</span> من الأسبوع الماضي
                </p>
              </CardContent>
            </Card>
          );
        })}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>المشاهدات اليومية</CardTitle>
            <CardDescription>آخر 7 أيام</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={viewsData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="views" fill="hsl(var(--primary))" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>معدل التفاعل</CardTitle>
            <CardDescription>آخر 7 أيام</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={engagementData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="day" />
                <YAxis />
                <Tooltip />
                <Line 
                  type="monotone" 
                  dataKey="engagement" 
                  stroke="hsl(var(--primary))" 
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>توصيات لتحسين المحتوى</CardTitle>
          <CardDescription>بناءً على تحليل أدائك</CardDescription>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            <li className="flex items-start gap-2">
              <span className="text-green-500">✓</span>
              <span className="text-sm">أفضل وقت للنشر: بين الساعة 6-9 مساءً</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500">✓</span>
              <span className="text-sm">المحتوى التعليمي يحقق أعلى تفاعل لديك</span>
            </li>
            <li className="flex items-start gap-2">
              <span className="text-green-500">✓</span>
              <span className="text-sm">استخدم الهاشتاجات الرائجة لزيادة الوصول</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

