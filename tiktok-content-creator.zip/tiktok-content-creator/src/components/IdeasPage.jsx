import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Lightbulb, Sparkles, TrendingUp } from 'lucide-react';

export default function IdeasPage() {
  const [ideas, setIdeas] = useState([
    {
      id: 1,
      title: 'تحدي الرقص الجديد',
      description: 'فيديو رقص على أحدث الأغاني الرائجة مع مؤثرات بصرية مميزة',
      category: 'رقص',
      trending: true
    },
    {
      id: 2,
      title: 'نصائح يومية للإنتاجية',
      description: 'مشاركة نصيحة سريعة لزيادة الإنتاجية في 30 ثانية',
      category: 'تعليمي',
      trending: false
    },
    {
      id: 3,
      title: 'وصفة طبخ سريعة',
      description: 'تحضير وجبة لذيذة في أقل من 5 دقائق',
      category: 'طبخ',
      trending: true
    }
  ]);

  const [loading, setLoading] = useState(false);

  const generateNewIdea = () => {
    setLoading(true);
    // محاكاة استدعاء API للذكاء الاصطناعي
    setTimeout(() => {
      const newIdea = {
        id: ideas.length + 1,
        title: 'فكرة جديدة من الذكاء الاصطناعي',
        description: 'فكرة مبتكرة تم توليدها بناءً على التريندات الحالية واهتماماتك',
        category: 'متنوع',
        trending: false
      };
      setIdeas([newIdea, ...ideas]);
      setLoading(false);
    }, 1500);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold tracking-tight">أفكار الفيديو</h2>
          <p className="text-muted-foreground">
            اكتشف أفكارًا مخصصة بناءً على التريندات الحالية
          </p>
        </div>
        <Button 
          onClick={generateNewIdea} 
          disabled={loading}
          className="gap-2"
        >
          <Sparkles className="h-4 w-4" />
          {loading ? 'جاري التوليد...' : 'توليد فكرة جديدة'}
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {ideas.map((idea) => (
          <Card key={idea.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <Lightbulb className="h-5 w-5 text-primary" />
                {idea.trending && (
                  <div className="flex items-center gap-1 text-xs text-orange-500">
                    <TrendingUp className="h-3 w-3" />
                    رائج
                  </div>
                )}
              </div>
              <CardTitle className="text-xl">{idea.title}</CardTitle>
              <CardDescription className="text-sm">
                {idea.category}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {idea.description}
              </p>
              <Button variant="outline" className="w-full">
                إنشاء سيناريو
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

