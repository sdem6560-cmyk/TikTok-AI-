import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx';
import { Film, Music, Sparkles, Download } from 'lucide-react';

export default function MediaLibraryPage() {
  const templates = [
    { id: 1, name: 'قالب عصري', category: 'رقص', preview: '🎬' },
    { id: 2, name: 'قالب احترافي', category: 'تعليمي', preview: '📚' },
    { id: 3, name: 'قالب مرح', category: 'ترفيه', preview: '🎉' }
  ];

  const effects = [
    { id: 1, name: 'تأثير بريق', type: 'بصري', preview: '✨' },
    { id: 2, name: 'تأثير انتقال سلس', type: 'حركة', preview: '🌊' },
    { id: 3, name: 'تأثير نيون', type: 'إضاءة', preview: '💡' }
  ];

  const music = [
    { id: 1, name: 'موسيقى حماسية', duration: '2:30', preview: '🎵' },
    { id: 2, name: 'موسيقى هادئة', duration: '3:00', preview: '🎶' },
    { id: 3, name: 'موسيقى إلكترونية', duration: '2:45', preview: '🎧' }
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">مكتبة الوسائط</h2>
        <p className="text-muted-foreground">
          تصفح القوالب والمؤثرات والموسيقى لفيديوهاتك
        </p>
      </div>

      <Tabs defaultValue="templates" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="templates">القوالب</TabsTrigger>
          <TabsTrigger value="effects">المؤثرات</TabsTrigger>
          <TabsTrigger value="music">الموسيقى</TabsTrigger>
        </TabsList>

        <TabsContent value="templates" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            {templates.map((template) => (
              <Card key={template.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="text-4xl text-center mb-2">{template.preview}</div>
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <CardDescription>{template.category}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full gap-2">
                    <Download className="h-4 w-4" />
                    استخدام القالب
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="effects" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            {effects.map((effect) => (
              <Card key={effect.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="text-4xl text-center mb-2">{effect.preview}</div>
                  <CardTitle className="text-lg">{effect.name}</CardTitle>
                  <CardDescription>{effect.type}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full gap-2">
                    <Sparkles className="h-4 w-4" />
                    إضافة المؤثر
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="music" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            {music.map((track) => (
              <Card key={track.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="text-4xl text-center mb-2">{track.preview}</div>
                  <CardTitle className="text-lg">{track.name}</CardTitle>
                  <CardDescription>{track.duration}</CardDescription>
                </CardHeader>
                <CardContent>
                  <Button variant="outline" className="w-full gap-2">
                    <Music className="h-4 w-4" />
                    استخدام الموسيقى
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

