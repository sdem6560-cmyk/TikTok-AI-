import { useState } from 'react';
import { Button } from '@/components/ui/button.jsx';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { FileText, Video, Edit } from 'lucide-react';

export default function ScenariosPage() {
  const [scenarios] = useState([
    {
      id: 1,
      title: 'سيناريو تحدي الرقص',
      duration: '30 ثانية',
      scenes: 3,
      content: 'المشهد 1: مقدمة بموسيقى حماسية\nالمشهد 2: أداء الرقصة\nالمشهد 3: خاتمة مع دعوة للمتابعة'
    },
    {
      id: 2,
      title: 'سيناريو نصائح الإنتاجية',
      duration: '45 ثانية',
      scenes: 2,
      content: 'المشهد 1: عرض المشكلة\nالمشهد 2: تقديم الحل والنصيحة'
    }
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold tracking-tight">السيناريوهات</h2>
        <p className="text-muted-foreground">
          إدارة وتحرير السيناريوهات الخاصة بك
        </p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {scenarios.map((scenario) => (
          <Card key={scenario.id} className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <FileText className="h-5 w-5 text-primary" />
                <div className="text-xs text-muted-foreground">
                  {scenario.scenes} مشاهد • {scenario.duration}
                </div>
              </div>
              <CardTitle className="text-xl">{scenario.title}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="bg-muted p-3 rounded-md text-sm whitespace-pre-line">
                  {scenario.content}
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 gap-2">
                    <Edit className="h-4 w-4" />
                    تحرير
                  </Button>
                  <Button className="flex-1 gap-2">
                    <Video className="h-4 w-4" />
                    تحويل إلى فيديو
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

